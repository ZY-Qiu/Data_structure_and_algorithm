#include <iostream>
#include <string>
#include "array.hpp"
using namespace std;

string str = "";

void print(Array<int>& a)
{
	for (int i = 0; i < a.size(); i++)
	{
		cout << a[i] << " ";
	}
	cout << endl;
}

void stackPermutarion(Array<int>& a1, Array<int>& a2, int m)
{
	Array<int> arr1, arr2;
	int index1, index2;

	for (int i = 0; i < a2.size(); i++)
	{
		index1 = a1.find(a2[i]);
		index2 = arr1.find(a2[i]);

		//cout << "Try array2[" << i << "] = " << a2[i] << endl;
		//cout << "index1 = " << index1 << ", array1.size() = " << a1.size() << endl;

		if (index1 != -1)
		{
			int s = a1.size();
			for (int j = 0; j < s - index1; j++)
			{
				arr1.push_back(a1.pop_back());
				str += "push\n";
				//cout << "push" << endl;
				if (arr1.size() > m)
				{
					cout << "No: S size not enough" << endl;
					return;
				}
			}
			arr2.push_back(arr1.pop_back());
			str += "pop\n";
			//cout << "pop" << endl;
		}
		else if (index2 != -1)
		{
			if (index2 != arr1.size() - 1)
			{
				cout << "No: Unable to operate" << endl;
				return;
			}
			else
			{
				arr2.push_back(arr1.pop_back());
				str += "pop\n";
				//cout << "pop" << endl;
			}
		}
	}
	cout << str;
	return;
}


int main()
{
	Array<int> arr1;
	Array<int> arr2;
	
	int n, m;
	cin >> n >> m; // n�ڳ��ᣬ��תվ��Сm

	for (int i = n; i > 0; i--)
	{
		arr1.push_back(i);
	}
	//cout << "��������" << endl;
	int a;
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &a);
		arr2.push_back(a);
	}

	//print(arr2);
	stackPermutarion(arr1, arr2, m);

	//system("pause");
	return 0;
}