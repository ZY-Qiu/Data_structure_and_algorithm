#include<iostream>
#include"PQ_ComplHeap.hpp"
using namespace std;

struct Task
{
	long long int priority;
	char name[9];
	bool operator>(const Task& t) // �ж����ȼ����ߣ������ָ�С����ASCII˳���С
	{
		if (priority == t.priority)
		{
			if (strcmp(name, t.name) < 0)
			{
				return false;
			}
			return true;
		}
		return priority > t.priority;
	}

}task[4000000];

int main()
{
	int n, m;
	scanf_s("%d %d", &n, &m);


	for (int i = 0; i < n; i++)
	{
		//scanf_s("%lld %s", &(task[i].priority), &(task[i].name));
		cin >> task[i].priority >> task[i].name;
	}

	PQ_ComplHeap<Task> heap(task, n);

	for (int i = 0; i < m; i++)
	{
		Task max = heap.delMax();
		max.priority *= 2;
		cout << max.name << endl;
		heap.insert(max);
	}

	return 0;
}